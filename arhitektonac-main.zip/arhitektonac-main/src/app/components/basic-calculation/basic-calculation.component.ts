import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

var FileSaver = require('file-saver');
import {
  AlignmentType,
  Document,
  HeadingLevel,
  Packer,
  Paragraph,
  TabStopPosition,
  TabStopType,
  TextRun,
  BorderStyle,
  Table,
  TableCell,
  TableRow
} from "docx";

@Component({
  selector: 'app-basic-calculation',
  templateUrl: './basic-calculation.component.html',
  styleUrls: ['./basic-calculation.component.scss']
})
export class BasicCalculationComponent implements OnInit {
  title = "CALCULATOR FOR DUNDJERS "
  k = 0.9
  δ = 1.15
  registerForm = this.getForma()
  submitted: boolean | undefined
  error = ''
  loading: boolean | undefined
  client: any

  constructor(private formBuilder: FormBuilder) {
  }

  ngOnInit(): void {
    console.log("on init")
  }

  getForma() {
    return this.formBuilder.group({
      Mu: ['', Validators.required],
      h: ['', Validators.required],
      ςv: ['', Validators.required],
      k: ['', Validators.required],
      δ: ['', Validators.required]
    })
  }

  onSubmit() {
    this.submitted = true
    if (this.registerForm.invalid) {
      console.error("Invalid filled form: ", this.registerForm)
      return
    } else {
    }
  }

  public get Mu() {
    return this.registerForm.controls.Mu.value
  }

  public get h() {
    return this.registerForm.controls.h.value
  }

  public get ςv() {
    return this.registerForm.controls.ςv.value
  }

  public get A() {
    return this.Mu / this.secundStep;
  }

  public get secundStep() {
    return this.k * this.h * this.ςv / this.δ;

  }

  public getCv() {
    return this.ςv;
  }

  public getB() {
    return this.δ;
  }

  isEnteredAllData() {
    return this.Mu === "" || this.h === "" || this.ςv === "";
  }

  public download(): void {
    let blob = new Blob([this.printVariables() + this.printFirstStep() + "\n" + this.printSecondStep() + "\nA=" + this.A.toFixed(2)], {type: "text/plain;charset=utf-8"});
    FileSaver.saveAs(blob, "result_for_"+this.printVariables()+".docx");
  }

   download2(){

     var html :any= document.getElementById("forPrint");

    let text= html.innerText.replace(/<[^>]*>/g, "");

     var tempDivElement = document.createElement("div");

     // Set the HTML content with the given value

     // Retrieve the text property of the element
     return tempDivElement.textContent || tempDivElement.innerText || "";
    var blob = new Blob([text], {type: "text/plain"});
    var url = window.URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = "NOVI";
    a.click();
  }


  printVariables() {
    return "k = 0.9\nδ = 1.15\nMu=" + this.Mu + "\nςv=" + this.ςv + "\nh=" + this.h + "\n\n";
  }

  public printFirstStep() {
    return "A= " + this.Mu.toFixed(2) + " / " + this.k.toFixed(2) + " * " + this.h.toFixed(2) + " * " + this.getCv().toFixed(2) + " /" + 1.15;
  }

  public printSecondStep() {
    return "A= " + this.Mu.toFixed(2) + " / " + this.secundStep.toFixed(2);
  }

  public khcv() {
    return this.k * this.h * this.ςv
  }

  public printKhcv() {
    return this.k + "*" + this.h + "*" + this.ςv
  }
}
