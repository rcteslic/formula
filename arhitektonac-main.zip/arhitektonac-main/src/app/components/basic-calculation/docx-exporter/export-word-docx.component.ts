import {Component, OnInit} from '@angular/core';
import { Packer } from 'docx';
var FileSaver = require('file-saver');
@Component({
  selector: 'app-export-word-docx',
  templateUrl: './export-word-docx.component.html',
  styleUrls: ['./export-word-docx.component.scss']
})
export class ExportWordDocxComponent {
  constructor() {
  }

  public download(): void {
    let blob = new Blob(["Hello, world!"], {type: "text/plain;charset=utf-8"});
    FileSaver.saveAs(blob, "hello world.txt");
  }
}
